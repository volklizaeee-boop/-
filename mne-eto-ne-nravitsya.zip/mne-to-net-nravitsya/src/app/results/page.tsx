import { Suspense } from 'react';

import { ResultsView } from '@/components/ResultsView';
import { MovieGridSkeleton } from '@/components/SkeletonCard';

export const dynamic = 'force-dynamic';

/**
 * useSearchParams() требует границу Suspense — поэтому ResultsView живёт внутри неё.
 * state-хранилище — только в URL, ссылку можно делиться.
 */
export default function ResultsPage() {
  return (
    <Suspense fallback={<div className="mx-auto max-w-7xl px-4 pb-24 pt-6 sm:px-6"><MovieGridSkeleton count={10} /></div>}>
      <ResultsView />
    </Suspense>
  );
}
