/**
 * Единственный маршрут, который читает TMDB_API_KEY.
 * Ключ никогда не попадает в браузер: клиент говорит только «исключить это», а мы оборачиваем
 * запрос в without_genres / without_keywords на сервере.
 */

import { NextResponse } from 'next/server';
import { TAGS } from '@/lib/filters';

import {
  TMDB_KEY_INSTRUCTIONS,
  TmdbError,
  discoverMovies,
  getApiKey,
  getGenres,
  resolveTags,
  resolveEndingKeywords,
} from '@/lib/tmdb';
import type { EndingPreference, FetchMoviesParams, MoviesResult } from '@/lib/types';

export const dynamic = 'force-dynamic';
export const maxDuration = 15;

const ENDING_VALUES: readonly string[] = ['any', 'good', 'sad'];
const MAX_PAGE = 500;

/** Разбирает «1,2,3» в [1,2,3], игнорируя что угодно другое. */
function parseIdList(raw: string | null): number[] {
  if (!raw) return [];
  return raw
    .split(',')
    .map((chunk) => Number.parseInt(chunk.trim(), 10))
    .filter((value) => Number.isInteger(value) && value > 0);
}

function parseEnding(raw: string | null): EndingPreference {
  return raw === 'good' || raw === 'sad' ? raw : 'any';
}

function parsePage(raw: string | null): number {
  const parsed = Number.parseInt(raw ?? '1', 10);
  if (!Number.isInteger(parsed) || parsed < 1) return 1;
  return Math.min(parsed, MAX_PAGE);
}

function keyMissingResponse(): NextResponse {
  return NextResponse.json(
    {
      error: {
        code: 'TMDB_API_KEY_MISSING',
        message: 'Ключ TMDB_API_KEY не задан — запрос фильмов недоступен.',
        instructions: [...TMDB_KEY_INSTRUCTIONS],
      },
    },
    { status: 503 },
  );
}

export async function GET(request: Request): Promise<NextResponse> {
  const apiKey = getApiKey();
  if (!apiKey) {
    return keyMissingResponse();
  }

  const url = new URL(request.url);
  const searchParams = url.searchParams;

  const params: FetchMoviesParams = {
    excludeGenres: parseIdList(searchParams.get('exclude_genres')),
    excludeKeywords: parseIdList(searchParams.get('exclude_keywords')),
    ending: parseEnding(searchParams.get('ending')),
    page: parsePage(searchParams.get('page')),
  };

  try {
    const signal = AbortSignal.timeout(15_000);
    if (searchParams.get('resource') === 'genres') {
      const genres = await getGenres(apiKey, { signal });
      return NextResponse.json({ genres }, { headers: { 'Cache-Control': 'no-store' } });
    }
    if (searchParams.get('resource') === 'tags') {
      const [tags, endings] = await Promise.all([
        resolveTags(TAGS, apiKey, { signal }), resolveEndingKeywords(apiKey, { signal }),
      ]);
      const failedCount = tags.filter((tag) => !tag.resolved).length;
      const serviceStatus = failedCount === 0 ? 'ok' : failedCount === tags.length ? 'down' : 'degraded';
      return NextResponse.json({ tags, endings, serviceStatus }, { headers: { 'Cache-Control': 'no-store' } });
    }
    const result = await discoverMovies(params, apiKey, {
      signal,
    });

    return NextResponse.json(result, {
      headers: { 'Cache-Control': 'no-store' },
    });
  } catch (cause) {
    if (cause instanceof TmdbError) {
      return NextResponse.json(
        {
          error: {
            code: 'TMDB_REQUEST_FAILED',
            message: cause.message,
            status: cause.status,
          },
        },
        { status: 502 },
      );
    }

    return NextResponse.json(
      {
        error: {
          code: 'UNEXPECTED_ERROR',
          message: 'Непредвиденная ошибка сервера. Попробуйте ещё раз.',
        },
      },
      { status: 500 },
    );
  }
}
