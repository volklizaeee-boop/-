'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';

import { AccordionSection } from '@/components/AccordionSection';
import { EndingSelector } from '@/components/EndingSelector';
import { FilterSkeleton } from '@/components/FilterSkeleton';
import { FilterSummary } from '@/components/FilterSummary';
import { GenreSelector } from '@/components/GenreSelector';
import { MissingApiKeyPanel } from '@/components/MissingApiKeyPanel';
import { TagSelector } from '@/components/TagSelector';
import {
  APP_HEADLINE,
  APP_SUBHEADLINE,
  ENDING_FILTER_NOTE,
  getGenreLabel,
} from '@/lib/filters';
import { ApiClientError, fetchGenres, fetchTags } from '@/lib/movie-api';
import { formatExclusionSummary } from '@/lib/format';
import type {
  EndingPreference,
  ResolvedEndingKeyword,
  ResolvedTag,
  TmdbGenre,
} from '@/lib/types';

const STORAGE_KEYS = {
  genres: 'mne-not-like.excludeGenres.v1',
  tags: 'mne-not-like.excludeTags.v1',
  ending: 'mne-not-like.ending.v1',
} as const;

type Status = 'loading' | 'ready' | 'error';

/** Безопасная чтение ID из localStorage. */
function loadIdList(key: string): number[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (value): value is number => typeof value === 'number' && Number.isInteger(value) && value > 0,
    );
  } catch {
    return [];
  }
}

/** Безопасная запись ID в localStorage. */
function saveIdList(key: string, values: ReadonlySet<number>): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(key, JSON.stringify(Array.from(values)));
  } catch {
    /* localStorage может быть заблокирован — это не критично */
  }
}

function saveEnding(value: EndingPreference): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(STORAGE_KEYS.ending, JSON.stringify(value));
  } catch {
    /* не критично */
  }
}

function loadEnding(): EndingPreference {
  if (typeof window === 'undefined') return 'any';
  try {
    const raw = window.localStorage.getItem(STORAGE_KEYS.ending);
    const parsed: unknown = JSON.parse(raw ?? '');
    return parsed === 'good' || parsed === 'sad' ? parsed : 'any';
  } catch {
    return 'any';
  }
}

export default function HomePage() {
  const router = useRouter();

  const [status, setStatus] = useState<Status>('loading');
  const [loadError, setLoadError] = useState<{ message: string; instructions: string[] | null } | null>(
    null,
  );
  const [genres, setGenres] = useState<TmdbGenre[]>([]);
  const [tags, setTags] = useState<ResolvedTag[]>([]);
  const [endings, setEndings] = useState<ResolvedEndingKeyword[]>([]);
  const [serviceStatus, setServiceStatus] = useState<'ok' | 'degraded' | 'down'>('ok');

  const [selectedGenres, setSelectedGenres] = useState<ReadonlySet<number>>(new Set());
  const [selectedTags, setSelectedTags] = useState<ReadonlySet<number>>(new Set());
  const [ending, setEnding] = useState<EndingPreference>('any');
  const [hydrated, setHydrated] = useState(false);

  /* ---------------- метаданные фильтров ---------------- */

  useEffect(() => {
    const controller = new AbortController();
    let cancelled = false;

    (async () => {
      try {
        const [genreList, tagList] = await Promise.all([
          fetchGenres(controller.signal),
          fetchTags(controller.signal),
        ]);

        if (cancelled) return;

        setGenres(genreList);
        setTags(tagList.tags);
        setEndings(tagList.endings);
        setServiceStatus(tagList.serviceStatus);
        setStatus('ready');
      } catch (cause) {
        if (cancelled || controller.signal.aborted) return;

        if (cause instanceof ApiClientError) {
          setLoadError({ message: cause.message, instructions: cause.instructions });
        } else {
          setLoadError({ message: 'Не удалось загрузить фильтры — проверьте подключение.', instructions: null });
        }
        setStatus('error');
      }
    })();

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, []);

  /* ---------------- восстановление выбора из localStorage ---------------- */

  useEffect(() => {
    const url = new URLSearchParams(window.location.search);
    const fromUrl = url.has('exclude_genres') || url.has('exclude_keywords') || url.has('ending');
    const ids = (value: string | null) => (value ?? '').split(',').map(Number).filter((id) => Number.isInteger(id) && id > 0);
    const restoredGenres = fromUrl ? ids(url.get('exclude_genres')) : loadIdList(STORAGE_KEYS.genres);
    if (restoredGenres.length > 0) setSelectedGenres(new Set(restoredGenres));

    const restoredTags = fromUrl ? ids(url.get('exclude_keywords')) : loadIdList(STORAGE_KEYS.tags);
    if (restoredTags.length > 0) setSelectedTags(new Set(restoredTags));

    const urlEnding = url.get('ending');
    const restoredEnding = fromUrl ? (urlEnding === 'good' || urlEnding === 'sad' ? urlEnding : 'any') : loadEnding();
    if (restoredEnding !== 'any') setEnding(restoredEnding);
    setHydrated(true);
  }, []);

  /* ---------------- сохранение выбора ---------------- */

  useEffect(() => {
    if (hydrated) saveIdList(STORAGE_KEYS.genres, selectedGenres);
  }, [selectedGenres, hydrated]);

  useEffect(() => {
    if (hydrated) saveIdList(STORAGE_KEYS.tags, selectedTags);
  }, [selectedTags, hydrated]);

  useEffect(() => {
    if (hydrated) saveEnding(ending);
  }, [ending, hydrated]);

  /* ---------------- защита от « ghost »-ID ---------------- */

  useEffect(() => {
    if (tags.length === 0) return;
    const available = new Set(
      tags.filter((tag): tag is ResolvedTag & { id: number } => tag.id !== null).map((tag) => tag.id),
    );

    setSelectedTags((previous) => {
      if (available.size === 0) return previous;
      const next = new Set([...previous].filter((id) => available.has(id)));
      return next.size === previous.size ? previous : next;
    });
  }, [tags]);

  /* ---------------- handlers ---------------- */

  const handleToggleGenre = useCallback((genreId: number) => {
    setSelectedGenres((previous) => {
      const next = new Set(previous);
      if (next.has(genreId)) next.delete(genreId);
      else next.add(genreId);
      return next;
    });
  }, []);

  const handleToggleTag = useCallback((tagId: number) => {
    setSelectedTags((previous) => {
      const next = new Set(previous);
      if (next.has(tagId)) next.delete(tagId);
      else next.add(tagId);
      return next;
    });
  }, []);

  const handleReset = useCallback(() => {
    setSelectedGenres(new Set());
    setSelectedTags(new Set());
    setEnding('any');
    if (typeof window !== 'undefined') {
      try {
        window.localStorage.removeItem(STORAGE_KEYS.genres);
        window.localStorage.removeItem(STORAGE_KEYS.tags);
        window.localStorage.removeItem(STORAGE_KEYS.ending);
      } catch { /* storage unavailable */ }
    }
  }, []);

  const handleShowResults = useCallback(() => {
    const search = new URLSearchParams();

    if (selectedGenres.size > 0) {
      search.set('exclude_genres', [...selectedGenres].sort((a, b) => a - b).join(','));
    }
    if (selectedTags.size > 0) {
      search.set('exclude_keywords', [...selectedTags].sort((a, b) => a - b).join(','));
    }
    if (ending !== 'any') {
      search.set('ending', ending);
    }

    router.push(`/results?${search.toString()}`);
  }, [router, selectedGenres, selectedTags, ending]);

  /* ---------------- derived ---------------- */

  const genresById = useMemo(
    () => new Map(genres.map((genre) => [genre.id, getGenreLabel(genre.name)])),
    [genres],
  );
  const tagsById = useMemo(
    () =>
      new Map(
        tags
          .filter((tag): tag is ResolvedTag & { id: number } => tag.id !== null)
          .map((tag) => [tag.id, tag.label]),
      ),
    [tags],
  );

  const unresolvedEndingKeywords = useMemo(
    () => endings.filter((entry) => entry.preference === ending && !entry.resolved).map((entry) => entry.keyword),
    [endings, ending],
  );

  const canSubmit = status === 'ready';

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-col gap-6 px-4 pb-40 pt-8 sm:px-6 sm:pt-12">
      <header className="space-y-3">
        <p className="m-0 text-xs font-semibold uppercase tracking-[0.2em] text-accent/80">
          Подборщик фильмов · TMDB
        </p>
        <h1 className="m-0 text-2xl font-bold leading-tight text-zinc-50 sm:text-4xl">
          Мне это не нравится
        </h1>
        <p className="m-0 max-w-2xl text-sm leading-relaxed text-zinc-400 sm:text-base">
          {APP_HEADLINE}
        </p>
      </header>

      {status === 'loading' ? (
        <FilterSkeleton />
      ) : loadError ? (
        loadError.instructions ? (
          <MissingApiKeyPanel instructions={loadError.instructions} />
        ) : (
          <div role="alert" className="rounded-2xl border border-danger/40 bg-danger/[0.07] p-8 text-center">
            <p className="m-0 font-semibold text-danger">{loadError.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="mt-5 rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-base-950 transition-colors hover:bg-accent-400"
            >
              Повторить
            </button>
          </div>
        )
      ) : (
        <>
          {serviceStatus === 'down' && (
            <div role="status" className="rounded-2xl border border-danger/40 bg-danger/[0.07] p-4 text-sm text-zinc-300">
              TMDB недоступен — метки не резолвились. Жанры и фильмы могут всё ещё работать.
            </div>
          )}

          <AccordionSection
            id="genres"
            title="Жанры"
            subtitle="Жёсткий фильтр: такие фильмы исчезнут из выдачи"
            badge={
              selectedGenres.size > 0 ? (
                <span className="rounded-full bg-accent/15 px-2.5 py-0.5 text-xs font-semibold text-accent">
                  {selectedGenres.size}
                </span>
              ) : null
            }
            defaultOpen
          >
            <GenreSelector genres={genres} selected={selectedGenres} onToggle={handleToggleGenre} />
          </AccordionSection>

          <AccordionSection
            id="tags"
            title="Метки и клише"
            subtitle="Жёсткий фильтр по тропам TMDB"
            badge={
              selectedTags.size > 0 ? (
                <span className="rounded-full bg-accent/15 px-2.5 py-0.5 text-xs font-semibold text-accent">
                  {selectedTags.size}
                </span>
              ) : null
            }
          >
            <TagSelector tags={tags} selected={selectedTags} onToggle={handleToggleTag} />
          </AccordionSection>

          <AccordionSection
            id="ending"
            title="Финал"
            subtitle="Мягкий фильтр — работает неточно"
            badge={
              ending !== 'any' ? (
                <span className="rounded-full bg-accent/15 px-2.5 py-0.5 text-xs font-semibold text-accent">
                  {ending === 'good' ? 'хороший' : 'грустный'}
                </span>
              ) : null
            }
          >
            <EndingSelector
              value={ending}
              onChange={setEnding}
              unresolvedKeywords={unresolvedEndingKeywords}
            />
          </AccordionSection>
          <p className="-mt-3 text-xs leading-relaxed text-zinc-400">{ENDING_FILTER_NOTE}</p>

          <FilterSummary
            excludedGenres={[...selectedGenres]}
            excludedTags={[...selectedTags]}
            ending={ending}
            genresById={genresById}
            tagsById={tagsById}
          />
        </>
      )}

      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-base-700/70 bg-base-950/90 px-4 py-4 backdrop-blur sm:px-6">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3">
          <p className="m-0 text-sm text-zinc-400">
            <span className="font-semibold text-accent">{formatExclusionSummary(selectedGenres.size, selectedTags.size)}</span>
          </p>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleReset}
              disabled={selectedGenres.size + selectedTags.size === 0 && ending === 'any'}
              className="rounded-xl border border-base-600 px-4 py-2.5 text-sm font-semibold text-zinc-200 transition-colors hover:border-danger hover:text-danger disabled:cursor-not-allowed disabled:opacity-40"
            >
              Сбросить всё
            </button>
            <button
              type="button"
              onClick={handleShowResults}
              disabled={!canSubmit}
              className="rounded-xl bg-accent px-6 py-2.5 text-sm font-semibold text-base-950 transition-colors hover:bg-accent-400 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Показать фильмы
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}
