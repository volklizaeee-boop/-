import type { Metadata } from 'next';

import './globals.css';

export const metadata: Metadata = {
  title: 'Мне это не нравится — подборщик фильмов',
  description:
    'Отметьте, чего не хотите видеть — жанр, троп или финал. Сайт исключит это и покажет остальное из TMDB.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <body className="min-h-screen font-sans">{children}</body>
    </html>
  );
}
