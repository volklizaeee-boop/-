/**
 * Клиентские запросы к собственным Route Handler.
 * Никакого TMDB_API_KEY здесь нет — ключ живёт только на сервере.
 */

import type {
  ApiErrorBody,
  GenresResponse,
  MoviesQuery,
  MoviesResult,
  ResolvedTag,
  ResolvedEndingKeyword,
  TagsResponse,
  TmdbGenre,
} from './types';

/** Ошибка, которую мы можем осмысленно показать пользователю. */
export class ApiClientError extends Error {
  readonly code: string;
  readonly status: number;
  readonly instructions: string[] | null;

  constructor(
    message: string,
    code: string,
    status: number,
    instructions: string[] | null = null,
  ) {
    super(message);
    this.name = 'ApiClientError';
    this.code = code;
    this.status = status;
    this.instructions = instructions;
  }
}

/** Выделывает читаемую ошибку из ответа Route Handler. */
async function toClientError(response: Response): Promise<ApiClientError> {
  const body = (await response.json().catch(() => null)) as ApiErrorBody | null;
  const error = body?.error;

  return new ApiClientError(
    error?.message ?? `Запрос не выполнен (HTTP ${response.status})`,
    error?.code ?? 'REQUEST_FAILED',
    response.status,
    error?.instructions ?? null,
  );
}

/** Список фильмов с фильтрацией и пагинацией. */
export async function fetchMoviesPage(
  query: MoviesQuery,
  signal?: AbortSignal,
): Promise<MoviesResult> {
  const search = new URLSearchParams();

  if (query.excludeGenres.length > 0) {
    search.set('exclude_genres', query.excludeGenres.join(','));
  }
  if (query.excludeKeywords.length > 0) {
    search.set('exclude_keywords', query.excludeKeywords.join(','));
  }
  if (query.ending !== 'any') {
    search.set('ending', query.ending);
  }
  if (query.page > 1) {
    search.set('page', String(query.page));
  }

  const response = await fetch(`/api/movies?${search.toString()}`, {
    signal,
    cache: 'no-store',
    headers: { Accept: 'application/json' },
  });

  if (!response.ok) {
    throw await toClientError(response);
  }

  return (await response.json()) as MoviesResult;
}

/** Список жанров — ключей в запросе нет, но запрос всё равно идёт через серверный Route Handler. */
export async function fetchGenres(signal?: AbortSignal): Promise<TmdbGenre[]> {
  const response = await fetch('/api/movies?resource=genres', { signal, cache: 'no-store' });
  if (!response.ok) throw await toClientError(response);

  const body = (await response.json()) as GenresResponse;
  return body.genres ?? [];
}

/** Метки/тропы + резолюция ключевых слов финала. */
export async function fetchTags(signal?: AbortSignal): Promise<{
  tags: ResolvedTag[];
  endings: ResolvedEndingKeyword[];
  serviceStatus: 'ok' | 'degraded' | 'down';
}> {
  const response = await fetch('/api/movies?resource=tags', { signal, cache: 'no-store' });
  if (!response.ok) throw await toClientError(response);

  const body = (await response.json()) as TagsResponse;
  return {
    tags: body.tags ?? [],
    endings: body.endings ?? [],
    serviceStatus: body.serviceStatus ?? 'ok',
  };
}
