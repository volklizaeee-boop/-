export function getPosterUrl(path: string | null, size: 'w342' | 'w500' | 'original' = 'w500'): string | null {
  return path ? `https://image.tmdb.org/t/p/${size}${path}` : null;
}
