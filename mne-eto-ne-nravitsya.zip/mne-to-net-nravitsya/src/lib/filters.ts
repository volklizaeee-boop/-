/**
 * Константы фильтров и русские подписи.
 * Файл не содержит сетевых запросов — им можно импортировать на клиент и на сервер.
 */

import type { EndingPreference } from './types';

/** Задаёт направление фильтрации по финалу. */
export interface EndingLabel {
  value: EndingPreference;
  label: string;
  hint: string;
}

/** Радиопункты блока «Финал». */
export const ENDING_OPTIONS: EndingLabel[] = [
  {
    value: 'any',
    label: 'Не важно',
    hint: 'Финал не учитываем — покажем всё без учёта финала.',
  },
  {
    value: 'good',
    label: 'Хочу хороший финал',
    hint: 'Исключим фильмы с грустным или трагичным финалом.',
  },
  {
    value: 'sad',
    label: 'Хочу грустный / трагичный финал',
    hint: 'Исключим фильмы с счастливым финалом.',
  },
];

/**
 * Ключевые слова TMDB, которые надо исключить для каждого выбора финала.
 * Резольвятся через /search/keyword на сервере (кэш в памяти).
 */
export const ENDING_KEYWORDS = ['happy ending', 'sad ending', 'bittersweet ending', 'tragic ending'] as const;

export const ENDING_FILTER: Record<Exclude<EndingPreference, 'any'>, string[]> = {
  good: ['sad ending', 'tragic ending'],
  sad: ['happy ending'],
};

/** Подпись, которую обязательно показываем под блоком «Финал». */
export const ENDING_FILTER_NOTE =
  'Фильтр по финалу работает неточно: TMDB размечает финалы не у всех фильмов.';

/** Описание смысла приложения. */
export const APP_HEADLINE = 'Отметьте, чего не хотите видеть — покажем остальное.';
export const APP_SUBHEADLINE =
  'Жанры, тропы и финалы. Чем больше отмечено, тем меньше похожих фильмов в выдаче.';

/** Определение одной метки/тропа. */
export interface TagDefinition {
  /** Подпись на русском, которую видит пользователь. */
  label: string;
  /** Запрос на английском для поиска keyword через /search/keyword. */
  keyword: string;
}

/**
 * Метки / тропы / клише.
 * Идёт через TMDB /search/keyword — ID не хардкодятся, резолвятся на сервере и кэшируются.
 */
export const TAGS: TagDefinition[] = [
  { label: 'Любовный треугольник', keyword: 'love triangle' },
  { label: 'Внезапный поворот сюжета', keyword: 'plot twist' },
  { label: 'Избранный', keyword: 'chosen one' },
  { label: 'Путешествие во времени', keyword: 'time travel' },
  { label: 'Амнезия', keyword: 'amnesia' },
  { label: 'Месть', keyword: 'revenge' },
  { label: 'Ограбление', keyword: 'heist' },
  { label: 'Взросление', keyword: 'coming of age' },
  { label: 'Постапокалипсис', keyword: 'post-apocalyptic' },
  { label: 'Найденная семья', keyword: 'found family' },
  { label: 'Ненадёжный рассказчик', keyword: 'unreliable narrator' },
  { label: 'Восхождение к славе', keyword: 'rise to fame' },
  { label: 'Выживание', keyword: 'survival' },
  { label: 'Супергерой', keyword: 'superhero' },
  { label: 'Зомби', keyword: 'zombie' },
  { label: 'Вампиры', keyword: 'vampire' },
  { label: 'Пришельцы', keyword: 'alien' },
  { label: 'Искусственный интеллект', keyword: 'artificial intelligence' },
  { label: 'Антиутопия', keyword: 'dystopia' },
  { label: 'Рождество', keyword: 'christmas' },
  { label: 'Свадьба', keyword: 'wedding' },
  { label: 'Школа', keyword: 'high school' },
  { label: 'Спорт', keyword: 'sport' },
  { label: 'Музыкальная группа', keyword: 'musical group' },
  { label: 'Погоня', keyword: 'chase' },
  { label: 'Дружба', keyword: 'friendship' },
  { label: 'Предательство', keyword: 'betrayal' },
  { label: 'Семейные тайны', keyword: 'family secrets' },
  { label: 'Дорога / роуд-муви', keyword: 'road trip' },
  { label: 'Конец света', keyword: 'end of the world' },
  { label: 'Драконы', keyword: 'dragon' },
  { label: 'Магия', keyword: 'magic' },
  { label: 'Средневековье', keyword: 'medieval' },
  { label: 'Космос', keyword: 'space' },
  { label: 'Крупный план / детектив', keyword: 'detective' },
  { label: 'Серийный убийца', keyword: 'serial killer' },
  { label: 'Время-цикл / день повторяется', keyword: 'time loop' },
  { label: 'Мутанты', keyword: 'mutant' },
  { label: 'Битва на мечах', keyword: 'sword fight' },
  { label: 'Волшебница / ведьма', keyword: 'witch' },
  { label: 'Принцесса', keyword: 'princess' },
  { label: 'Поиск сокровищ', keyword: 'treasure hunt' },
  { label: 'Погружение в разум', keyword: 'mind bending' },
  { label: 'Затерянный мир', keyword: 'lost world' },
];

/** Русские подписи жанров TMDB (fallback — английское имя). */
export const GENRE_NAMES_RU: Readonly<Record<string, string>> = {
  Action: 'Экшен',
  Adventure: 'Приключения',
  Animation: 'Анимационный',
  Comedy: 'Комедия',
  Crime: 'Криминал',
  Documentary: 'Документальный',
  Drama: 'Драма',
  Family: 'Семейный',
  Fantasy: 'Фэнтези',
  History: 'История',
  Horror: 'Ужасы',
  Music: 'Музыка',
  Mystery: 'Мистика',
  Romance: 'Романтика',
  'Science Fiction': 'Фантастика',
  'TV Movie': 'Телевизионный',
  Thriller: 'Триллер',
  War: 'Военный',
  Western: 'Вестерн',
};

/** Возвращает русское (или исходное) имя жанра. */
export function getGenreLabel(name: string): string {
  return GENRE_NAMES_RU[name] ?? name;
}
