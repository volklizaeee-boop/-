/**
 * Публичные типы приложения.
 * В интерфейсах ниже нет `any`: все значения явно типизированы.
 */

/** Выбор фильтра по финалу. */
export type EndingPreference = 'any' | 'good' | 'sad';

/** Жанр, который возвращает TMDB (/genre/movie/list). */
export interface TmdbGenre {
  id: number;
  name: string;
}

/** Ключевое слово TMDB (/search/keyword). */
export interface TmdbKeyword {
  id: number;
  name: string;
}

/** Жанр фильма (название нужно для карточки). */
export interface MovieGenre {
  id: number;
  name: string;
}

/** Фильм в форме, которую ожидает фронтенд. */
export interface Movie {
  id: number;
  title: string;
  originalTitle: string | null;
  overview: string | null;
  posterPath: string | null;
  backdropPath: string | null;
  releaseDate: string | null;
  voteAverage: number | null;
  voteCount: number | null;
  genreIds: number[];
  genres: MovieGenre[];
  adult: boolean;
}

/** Пакет страницы /discover/movie. */
export interface DiscoverMoviesPayload {
  page: number;
  results: Movie[];
  totalPages: number;
  totalResults: number;
}

/** Параметры запроса к /discover/movie. */
export interface FetchMoviesParams {
  /** ID жанров для исключения (without_genres). */
  excludeGenres: number[];
  /** ID ключевых слов для исключения (without_keywords). */
  excludeKeywords: number[];
  ending: EndingPreference;
  page: number;
}

/** Результат запроса к /discover/movie. */
export interface FetchMoviesResult {
  unresolvedKeywords: string[];
  movies: Movie[];
  page: number;
  totalPages: number;
  totalResults: number;
}

/** Клиентский запрос на список фильмов. */
export interface MoviesQuery {
  excludeGenres: number[];
  excludeKeywords: number[];
  ending: EndingPreference;
  page: number;
}

/** Клиентский ответ со списком фильмов. */
export interface MoviesResult {
  unresolvedKeywords: string[];
  movies: Movie[];
  page: number;
  totalPages: number;
  totalResults: number;
}

/** Исключённая метка/троп: ID ключевого слова TMDB. */
export interface ResolvedTag {
  /** Публичная подпись на русском. */
  label: string;
  /** Запрос-ключевое слово на английском. */
  keyword: string;
  /** ID в TMDB — null, если ключевое слово не найдено. */
  id: number | null;
  /** false — «не нашлось ключевое слово», фильтр недоступен. */
  resolved: boolean;
}

/** Определение метки/тропа — как в filters.ts, но без клиентских полей. */
export interface TagDefinitionLike {
  label: string;
  keyword: string;
}

/** Резолюция ключевых слов финала. */
export interface ResolvedEndingKeyword {
  preference: Extract<EndingPreference, 'good' | 'sad'>;
  keyword: string;
  id: number | null;
  resolved: boolean;
}

/** Ответ /api/movies/genres. */
export interface GenresResponse {
  genres: TmdbGenre[];
}

/** Ответ /api/movies/tags. */
export interface TagsResponse {
  tags: ResolvedTag[];
  endings: ResolvedEndingKeyword[];
  /**
   * ok — всё резолвилось;
   * degraded — часть ключевых слов не нашлась (и это нормально);
   * down — ни одно ключевое слово не резолвилось (TMDB, скорее всего, недоступен).
   */
  serviceStatus: 'ok' | 'degraded' | 'down';
}

/** Ошибка, которую возвращает Route Handler. */
export interface ApiErrorBody {
  error: {
    code: 'TMDB_API_KEY_MISSING' | 'TMDB_REQUEST_FAILED' | 'UNEXPECTED_ERROR';
    message: string;
    status?: number;
    instructions?: string[];
  };
}

/** Ответ Route Handler: либо данные, либо структурированная ошибка. */
export type ApiRouteResponse<T> = T | ApiErrorBody;
