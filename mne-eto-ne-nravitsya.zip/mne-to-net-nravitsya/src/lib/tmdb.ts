/**
 * Серверный клиент TMDB.
 * Ключ API не выходит за пределы сервера: все запросы отсюда делаются только в Route Handler.
 * Резолюции ключевых слов кэшируются в памяти (Map), чтобы не пилить /search/keyword на каждый запрос.
 */

import 'server-only';

import { ENDING_FILTER, ENDING_KEYWORDS } from './filters';
import type {
  EndingPreference,
  FetchMoviesParams,
  FetchMoviesResult,
  Movie,
  ResolvedEndingKeyword,
  ResolvedTag,
  TagDefinitionLike,
  TmdbGenre,
} from './types';

const TMDB_API_BASE = 'https://api.themoviedb.org/3';

/** TMDB не отдаёт ровно 1000 страниц — максимум 500. */
const MAX_PAGE = 500;

/** Размеры постеров. */
export type PosterSize = 'w342' | 'w500' | 'original';

/** Ошибка соединения с TMDB. */
export class TmdbError extends Error {
  readonly status: number | null;
  readonly retryable: boolean;

  constructor(message: string, options: { status?: number | null; retryable?: boolean } = {}) {
    super(message);
    this.name = 'TmdbError';
    this.status = options.status ?? null;
    this.retryable = options.retryable ?? true;
  }
}

/** Ошибка настроек — ключ не задан. */
export class TmdbConfigError extends Error {
  constructor(message = 'TMDB_API_KEY не задана') {
    super(message);
    this.name = 'TmdbConfigError';
  }
}

/** Пошаговая инструкция, где взять ключ. */
export const TMDB_KEY_INSTRUCTIONS: readonly string[] = [
  'Зарегистрируйте бесплатную учётную запись на themoviedb.org и войдите.',
  'Откройте профиль → раздел «API» (https://www.themoviedb.org/settings/api) и нажмите кнопку «Create».',
  'TMDB выдаст ключ API v3 (указан как API Key). Скопируйте его.',
  'В корне проекта создайте файл .env.local и запишите строку: TMDB_API_KEY="ваш_ключ"',
  'Перезапустите приложение: npm run dev. Ключ никуда не попадет в браузер — все запросы к TMDB идут через Route Handler на сервере.',
];

/** Читает ключ из окружения. Пустой ключ считается отсутствующим. */
export function getApiKey(): string | null {
  const raw = process.env.TMDB_API_KEY;
  if (!raw) return null;
  const key = raw.trim();
  return key.length > 0 ? key : null;
}

/** Ключ v4 (bearer-токен) — это JWT, начинается на `eyJ`. */
function isBearerToken(apiKey: string): boolean {
  return apiKey.startsWith('eyJ');
}

/** Добавляет авторизацию в URL/заголовки. */
function buildRequest(path: string, apiKey: string): { url: string; headers: Record<string, string> } {
  const headers: Record<string, string> = { Accept: 'application/json' };
  const bearer = isBearerToken(apiKey);

  if (bearer) {
    headers.Authorization = `Bearer ${apiKey}`;
    return { url: `${TMDB_API_BASE}${path}`, headers };
  }

  const joiner = path.includes('?') ? '&' : '?';
  return {
    url: `${TMDB_API_BASE}${path}${joiner}api_key=${encodeURIComponent(apiKey)}`,
    headers,
  };
}

/** Делает запрос к TMDB и разбирает JSON. */
async function tmdbFetch<TResponse>(
  path: string,
  apiKey: string,
  options: { signal?: AbortSignal } = {},
): Promise<TResponse> {
  const { url, headers } = buildRequest(path, apiKey);

  let response: Response;
  try {
    response = await fetch(url, {
      headers,
      cache: 'no-store',
      signal: options.signal,
    });
  } catch (cause) {
    if (options.signal?.aborted) throw cause;
    throw new TmdbError('Не удалось добраться до TMDB — проверьте подключение к сети.', {
      status: null,
      retryable: true,
    });
  }

  if (!response.ok) {
    const detail = await response.text().catch(() => '');
    throw new TmdbError(
      `TMDB вернул ошибку ${response.status}${detail ? `: ${detail.slice(0, 200)}` : ''}`,
      { status: response.status, retryable: response.status >= 500 || response.status === 429 },
    );
  }

  return (await response.json()) as TResponse;
}

/* ------------------------------------------------------------------ *
 * Кэши
 * ------------------------------------------------------------------ */

const keywordIdCache = new Map<string, number | null>();
let genreListCache: TmdbGenre[] | null = null;

/** Очистка кэша (используется в tests/debug). */
export function clearTmdbCaches(): void {
  keywordIdCache.clear();
  genreListCache = null;
}

/** Получает список жанров /genre/movie/list (кэшируется в памяти). */
export async function getGenres(
  apiKey: string,
  options: { signal?: AbortSignal } = {},
): Promise<TmdbGenre[]> {
  if (genreListCache && !options.signal) return genreListCache;

  const payload = await tmdbFetch<{ genres?: TmdbGenre[] }>('/genre/movie/list', apiKey, options);
  genreListCache = (payload.genres ?? []).map((genre) => ({
    id: genre.id,
    name: genre.name,
  }));
  return genreListCache;
}

/** Резолвит одно ключевое слово. null — «не нашлось» (не ошибка). */
export async function resolveKeywordId(
  keywordQuery: string,
  apiKey: string,
  options: { signal?: AbortSignal } = {},
): Promise<number | null> {
  const query = keywordQuery.trim();
  if (query.length === 0) return null;

  if (keywordIdCache.has(query)) {
    return keywordIdCache.get(query) ?? null;
  }

  const payload = await tmdbFetch<{ results?: Array<{ id: number; name: string }> }>(
    `/search/keyword?query=${encodeURIComponent(query)}`,
    apiKey,
    options,
  );

  const id = payload.results?.find((item) => item.name.toLowerCase().trim() === query.toLowerCase())?.id ?? null;
  keywordIdCache.set(query, id);
  return id;
}

interface KeywordResolution {
  query: string;
  id: number | null;
  resolved: boolean;
  failed: boolean;
}

/**
 * Резолвит несколько ключевых слов параллельно.
 * Один провал не ломает остальные: сломанное слово просто пропускается.
 */
export async function resolveKeywordIds(
  queries: readonly string[],
  apiKey: string,
  options: { signal?: AbortSignal } = {},
): Promise<KeywordResolution[]> {
  const unique = Array.from(new Set(queries.map((query) => query.trim()).filter((q) => q.length > 0)));

  const settled = await Promise.all(
    unique.map(async (query): Promise<KeywordResolution> => {
      try {
        const id = await resolveKeywordId(query, apiKey, options);
        return { query, id, resolved: id !== null, failed: false };
      } catch (cause) {
        if (options.signal?.aborted) throw cause;
        return { query, id: null, resolved: false, failed: true };
      }
    }),
  );

  return settled;
}

/** Метки (TAGS) с русскими подписями. Неразрешённые получают id: null. */
export async function resolveTags(
  tags: readonly TagDefinitionLike[],
  apiKey: string,
  options: { signal?: AbortSignal } = {},
): Promise<ResolvedTag[]> {
  const resolutions = await resolveKeywordIds(
    tags.map((tag) => tag.keyword),
    apiKey,
    options,
  );

  return tags.map((tag) => {
    const resolution = resolutions.find((item) => item.query === tag.keyword);
    const id = resolution?.id ?? null;
    return {
      label: tag.label,
      keyword: tag.keyword,
      id,
      resolved: id !== null,
    };
  });
}

/** Ключевые слова финала с привязкой к выбору пользователя. */
export async function resolveEndingKeywords(
  apiKey: string,
  options: { signal?: AbortSignal } = {},
): Promise<ResolvedEndingKeyword[]> {
  const entries: Array<[Extract<EndingPreference, 'good' | 'sad'>, readonly string[]]> = [
    ['good', ENDING_FILTER.good],
    ['sad', ENDING_FILTER.sad],
  ];

  const resolutions = await resolveKeywordIds(
    ENDING_KEYWORDS,
    apiKey,
    options,
  );

  return entries.flatMap(([preference, keywords]) =>
    keywords.map((keyword) => {
      const resolution = resolutions.find((item) => item.query === keyword);
      const id = resolution?.id ?? null;
      return { preference, keyword, id, resolved: id !== null };
    }),
  );
}

/* ------------------------------------------------------------------ *
 * Фильмы
 * ------------------------------------------------------------------ */

interface RawMovieGenre {
  id?: number;
  name?: string;
}

interface RawMovie {
  id?: number;
  title?: string;
  original_title?: string;
  overview?: string;
  poster_path?: string | null;
  backdrop_path?: string | null;
  release_date?: string | null;
  vote_average?: number | null;
  vote_count?: number | null;
  genre_ids?: number[];
  genres?: RawMovieGenre[];
  adult?: boolean;
}

/** Преобразует сырой ответ TMDB в безопасный typed объект. */
function normalizeMovie(raw: RawMovie): Movie {
  const genres: Movie['genres'] = Array.isArray(raw.genres)
    ? raw.genres
        .filter((genre) => typeof genre?.id === 'number' && typeof genre?.name === 'string')
        .map((genre) => ({ id: genre.id as number, name: genre.name as string }))
    : [];

  return {
    id: typeof raw.id === 'number' ? raw.id : 0,
    title: typeof raw.title === 'string' && raw.title.length > 0 ? raw.title : 'Без названия',
    originalTitle: typeof raw.original_title === 'string' ? raw.original_title : null,
    overview: typeof raw.overview === 'string' ? raw.overview : null,
    posterPath: typeof raw.poster_path === 'string' ? raw.poster_path : null,
    backdropPath: typeof raw.backdrop_path === 'string' ? raw.backdrop_path : null,
    releaseDate: typeof raw.release_date === 'string' ? raw.release_date : null,
    voteAverage: typeof raw.vote_average === 'number' ? raw.vote_average : null,
    voteCount: typeof raw.vote_count === 'number' ? raw.vote_count : null,
    genreIds: Array.isArray(raw.genre_ids)
      ? raw.genre_ids.filter((id): id is number => typeof id === 'number')
      : [],
    genres,
    adult: raw.adult === true,
  };
}

/** Оставляет только положительные целые, убирает дубли. */
function uniquePositiveInts(values: readonly number[]): number[] {
  const seen = new Set<number>();
  const result: number[] = [];

  for (const value of values) {
    if (Number.isInteger(value) && value > 0 && !seen.has(value)) {
      seen.add(value);
      result.push(value);
    }
  }

  return result;
}

/**
 * /discover/movie с without_genres / without_keywords.
 * `ending` добавляет ключевые слова финала в without_keywords — фильмы без разметки
 * всё равно остаются в выдаче (фильтр мягкий).
 */
export async function discoverMovies(
  params: FetchMoviesParams,
  apiKey: string,
  options: { signal?: AbortSignal } = {},
): Promise<FetchMoviesResult> {
  const search = new URLSearchParams({
    language: 'ru-RU',
    sort_by: 'popularity.desc',
    'vote_count.gte': '100',
    include_adult: 'false',
    include_video: 'false',
    page: String(params.page),
  });

  const genreIds = uniquePositiveInts(params.excludeGenres);
  if (genreIds.length > 0) {
    search.set('without_genres', genreIds.join(','));
  }

  const keywordIds = uniquePositiveInts(params.excludeKeywords);

  let unresolvedKeywords: string[] = [];
  if (params.ending !== 'any') {
    const endingResolutions = await resolveKeywordIds(ENDING_FILTER[params.ending], apiKey, options);
    if (endingResolutions.some((item) => item.failed)) throw new TmdbError('Не удалось загрузить ключевые слова финала. Попробуйте ещё раз.');
    unresolvedKeywords = endingResolutions.filter((item) => !item.resolved).map((item) => item.query);
    for (const resolution of endingResolutions) {
      if (resolution.id !== null) keywordIds.push(resolution.id);
    }
  }

  if (keywordIds.length > 0) {
    search.set('without_keywords', uniquePositiveInts(keywordIds).join(','));
  }

  const payload = await tmdbFetch<{ results?: RawMovie[]; page?: number; total_pages?: number; total_results?: number }>(
    `/discover/movie?${search.toString()}`,
    apiKey,
    options,
  );

  return {
    unresolvedKeywords,
    movies: (payload.results ?? []).map(normalizeMovie),
    page: typeof payload.page === 'number' ? payload.page : params.page,
    totalPages: Math.max(1, Math.min(typeof payload.total_pages === 'number' ? payload.total_pages : 1, MAX_PAGE)),
    totalResults: typeof payload.total_results === 'number' ? payload.total_results : 0,
  };
}

