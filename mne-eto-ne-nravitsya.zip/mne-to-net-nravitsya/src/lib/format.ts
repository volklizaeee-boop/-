/** Форматирование чисел и текста. */

interface PluralForms {
  one: string;
  few: string;
  many: string;
}

/** Русское склонение (жанр/жанра/жанров, метка/метки/меток). */
export function plural(count: number, forms: PluralForms): string {
  const absolute = Math.abs(count);
  const lastTwo = absolute % 100;
  const lastDigit = absolute % 10;

  if (lastTwo >= 11 && lastTwo <= 14) return forms.many;
  if (lastDigit === 1) return forms.one;
  if (lastDigit >= 2 && lastDigit <= 4) return forms.few;
  return forms.many;
}

/** «Исключено: 2 жанра, 5 меток». */
export function formatExclusionSummary(genreCount: number, tagCount: number): string {
  const genrePart =
    genreCount > 0
      ? `${genreCount} ${plural(genreCount, { one: 'жанр', few: 'жанра', many: 'жанров' })}`
      : '';
  const tagPart =
    tagCount > 0
      ? `${tagCount} ${plural(tagCount, { one: 'метка', few: 'метки', many: 'меток' })}`
      : '';

  const joined = [genrePart, tagPart].filter(Boolean).join(', ');
  return joined.length > 0 ? `Исключено: ${joined}` : 'Исключено: ничего';
}

/** Годы. */
export function formatYear(releaseDate: string | null): string | null {
  if (!releaseDate) return null;
  const year = releaseDate.slice(0, 4);
  return year.length === 4 ? year : null;
}

/** Рейтинг IMDb-style: «8.1». */
export function formatRating(voteAverage: number | null): string | null {
  if (voteAverage === null || voteAverage === undefined || Number.isNaN(voteAverage)) return null;
  return voteAverage.toFixed(1);
}

/** «12 450 оценок». */
export function formatVoteCount(voteCount: number | null): string | null {
  if (voteCount === null || voteCount === undefined || Number.isNaN(voteCount)) return null;
  return voteCount.toLocaleString('ru-RU');
}
