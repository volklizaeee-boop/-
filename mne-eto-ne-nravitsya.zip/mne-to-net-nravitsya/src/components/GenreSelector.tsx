import { getGenreLabel } from '@/lib/filters';
import type { TmdbGenre } from '@/lib/types';
import { CheckableChip } from './CheckableChip';

interface GenreSelectorProps {
  genres: TmdbGenre[];
  selected: ReadonlySet<number>;
  onToggle: (genreId: number) => void;
}

/** Жёсткий фильтр — сетка чипов жанров. */
export function GenreSelector({ genres, selected, onToggle }: GenreSelectorProps) {
  if (genres.length === 0) {
    return (
      <p className="text-sm text-zinc-500">
        Список жанров пока не загрузился. Попробуйте перезагрузить страницу.
      </p>
    );
  }

  const sorted = [...genres].sort((a, b) => getGenreLabel(a.name).localeCompare(getGenreLabel(b.name), 'ru'));

  return (
    <div>
      <p className="mb-3 text-xs text-zinc-500">
        Жёсткий фильтр: фильмы с отмеченными жанрами полностью исчезнут из выдачи.
      </p>
      <ul className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
        {sorted.map((genre) => {
          const id = String(genre.id);
          return (
            <li key={genre.id}>
              <CheckableChip
                id={`genre-${id}`}
                label={getGenreLabel(genre.name)}
                checked={selected.has(genre.id)}
                onChange={(checked) => onToggle(genre.id)}
              />
            </li>
          );
        })}
      </ul>
    </div>
  );
}
