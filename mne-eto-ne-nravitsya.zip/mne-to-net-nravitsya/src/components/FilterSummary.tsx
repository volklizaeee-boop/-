'use client';

import { ENDING_OPTIONS } from '@/lib/filters';
import { cn } from '@/lib/cn';
import { formatExclusionSummary, plural } from '@/lib/format';
import type { EndingPreference } from '@/lib/types';

interface FilterSummaryProps {
  excludedGenres: readonly number[];
  excludedTags: readonly number[];
  ending: EndingPreference;
  genresById: ReadonlyMap<number, string>;
  tagsById: ReadonlyMap<number, string>;
  variant?: 'full' | 'compact';
  onEditFilters?: () => void;
  className?: string;
}

/** Счётчик и список исключений: «Исключено: X жанров, Y меток». */
export function FilterSummary({
  excludedGenres,
  excludedTags,
  ending,
  genresById,
  tagsById,
  variant = 'full',
  onEditFilters,
  className,
}: FilterSummaryProps) {
  const genreNames = excludedGenres
    .map((id) => genresById.get(id))
    .filter((name): name is string => Boolean(name));
  const tagNames = excludedTags
    .map((id) => tagsById.get(id))
    .filter((name): name is string => Boolean(name));

  const endingLabel =
    ENDING_OPTIONS.find((option) => option.value === ending)?.label ?? 'Не важно';

  if (variant === 'compact') {
    return (
      <div
        className={cn(
          'flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-base-700 bg-base-900/70 px-4 py-3',
          className,
        )}
      >
        <p className="m-0 text-sm text-zinc-300">
          <span className="font-semibold text-accent">
            {formatExclusionSummary(genreNames.length, tagNames.length)}
          </span>
          {ending !== 'any' && <span className="ml-2 text-zinc-500">· финал: {endingLabel}</span>}
        </p>
        {onEditFilters && (
          <button
            type="button"
            onClick={onEditFilters}
            className="rounded-lg border border-base-600 px-3 py-1.5 text-sm font-medium text-zinc-200 transition-colors hover:border-accent hover:text-accent"
          >
            Изменить фильтры
          </button>
        )}
      </div>
    );
  }

  return (
    <div className={cn('rounded-2xl border border-base-700 bg-base-900/60 p-5', className)}>
      <p className="m-0 text-xs font-semibold uppercase tracking-wider text-zinc-500">
        Исключено на данный момент
      </p>
      <p className="mt-2 text-lg font-semibold text-accent">
        {formatExclusionSummary(genreNames.length, tagNames.length)}
        {ending !== 'any' && <span className="ml-2 text-base font-medium text-zinc-300">· финал: {endingLabel}</span>}
      </p>

      {genreNames.length > 0 && (
        <div className="mt-4">
          <p className="mb-2 text-xs text-zinc-500">
            Жанры ({excludedGenres.length} {plural(excludedGenres.length, { one: 'жанр', few: 'жанра', many: 'жанров' })})
          </p>
          <ul className="flex flex-wrap gap-2">
            {genreNames.map((name) => (
              <li
                key={name}
                className="rounded-lg border border-accent/30 bg-accent/10 px-2.5 py-1 text-xs text-accent-200"
              >
                {name}
              </li>
            ))}
          </ul>
        </div>
      )}

      {tagNames.length > 0 && (
        <div className="mt-4">
          <p className="mb-2 text-xs text-zinc-500">
            Метки и тропы ({excludedTags.length} {plural(excludedTags.length, { one: 'метка', few: 'метки', many: 'меток' })})
          </p>
          <ul className="flex flex-wrap gap-2">
            {tagNames.map((name) => (
              <li
                key={name}
                className="rounded-lg border border-danger/30 bg-danger/10 px-2.5 py-1 text-xs text-danger/90"
              >
                {name}
              </li>
            ))}
          </ul>
        </div>
      )}

      {genreNames.length === 0 && tagNames.length === 0 && ending === 'any' && (
        <p className="mt-4 text-sm text-zinc-500">
          Пока ничего не исключено — нажмите «Показать фильмы» и получите популярную выдачу TMDB.
        </p>
      )}

      {onEditFilters && (
        <button
          type="button"
          onClick={onEditFilters}
          className="mt-5 rounded-lg border border-base-600 px-3 py-1.5 text-sm font-medium text-zinc-200 transition-colors hover:border-accent hover:text-accent"
        >
          Изменить фильтры
        </button>
      )}
    </div>
  );
}
