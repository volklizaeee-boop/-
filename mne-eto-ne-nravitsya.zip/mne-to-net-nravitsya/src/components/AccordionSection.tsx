'use client';

import { useState, type ReactNode } from 'react';

import { cn } from '@/lib/cn';

interface AccordionSectionProps {
  id: string;
  title: string;
  subtitle?: string;
  /** Что показывать справа от заголовка (например, счётчик). */
  badge?: ReactNode;
  defaultOpen?: boolean;
  children: ReactNode;
}

/** Аккордеон с доступностью: кнопка, aria-expanded, клавиатура работает нативно. */
export function AccordionSection({
  id,
  title,
  subtitle,
  badge,
  defaultOpen = false,
  children,
}: AccordionSectionProps) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <section
      className="overflow-hidden rounded-2xl border border-base-700 bg-base-900/60 shadow-poster"
      aria-labelledby={`${id}-heading`}
    >
      <h2 id={`${id}-heading`} className="m-0">
        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          aria-expanded={open}
          aria-controls={`${id}-panel`}
          className={cn(
            'flex w-full items-center justify-between gap-4 px-5 py-4 text-left transition-colors hover:bg-base-850/70 sm:px-6',
          )}
        >
          <span className="min-w-0">
            <span className="block text-base font-semibold text-zinc-50 sm:text-lg">{title}</span>
            {subtitle && (
              <span className="mt-0.5 block text-sm text-zinc-500">{subtitle}</span>
            )}
          </span>
          <span className="flex shrink-0 items-center gap-3">
            {badge}
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
              className={cn(
                'h-5 w-5 text-accent transition-transform duration-200',
                open && 'rotate-180',
              )}
            >
              <path d="m6 9 6 6 6-6" />
            </svg>
          </span>
        </button>
      </h2>

      {open && (
        <div
          id={`${id}-panel`}
          role="region"
          aria-labelledby={`${id}-heading`}
          className="border-t border-base-700/70 px-5 py-5 animate-fadeIn sm:px-6"
        >
          {children}
        </div>
      )}
    </section>
  );
}
