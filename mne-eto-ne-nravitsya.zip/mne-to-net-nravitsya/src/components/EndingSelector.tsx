'use client';

import { ENDING_OPTIONS } from '@/lib/filters';
import { cn } from '@/lib/cn';
import type { EndingPreference } from '@/lib/types';

interface EndingSelectorProps {
  value: EndingPreference;
  onChange: (value: EndingPreference) => void;
  /** Ключевые слова финала, которые TMDB не смог найти (для мягкого уведомления). */
  unresolvedKeywords?: string[];
}

/** Мягкий фильтр — радиогруппа. */
export function EndingSelector({
  value,
  onChange,
  unresolvedKeywords = [],
}: EndingSelectorProps) {
  return (
    <div>
      <p className="mb-3 text-xs text-zinc-500">
        Мягкий фильтр: он работает неточно, но фильмы без разметки TMDB всё равно остаются в выдаче.
      </p>

      <div role="radiogroup" aria-label="Финал фильма" className="flex flex-col gap-2.5">
        {ENDING_OPTIONS.map((option) => (
          <label
            key={option.value}
            className={cn(
              'flex cursor-pointer items-start gap-3 rounded-xl border px-4 py-3 transition-colors',
              value === option.value
                ? 'border-accent bg-accent/10'
                : 'border-base-700 bg-base-900/70 hover:border-accent/40',
            )}
          >
            <input
              type="radio"
              name="ending"
              value={option.value}
              checked={value === option.value}
              onChange={() => onChange(option.value)}
              className="mt-0.5 h-4 w-4 accent-accent"
            />
            <span className="min-w-0">
              <span className="block text-sm font-semibold text-zinc-50">{option.label}</span>
              <span className="mt-0.5 block text-xs text-zinc-500">{option.hint}</span>
            </span>
          </label>
        ))}
      </div>

      {unresolvedKeywords.length > 0 && (
        <div role="status" className="mt-3 rounded-xl border border-base-600 bg-base-850/70 p-3 text-xs text-zinc-400">
          Ключевые слова {unresolvedKeywords.map((keyword) => `«${keyword}»`).join(', ')} не
          найдены в TMDB — этот фильтр финала к фильмам не применяется.
        </div>
      )}
    </div>
  );
}
