/** Скелетон блоков фильтров на главной. */
export function FilterSkeleton() {
  return (
    <div className="space-y-4" aria-hidden="true">
      <div className="shimmer-surface h-16 animate-shimmer rounded-2xl" />
      <div className="shimmer-surface h-40 animate-shimmer rounded-2xl" />
      <div className="shimmer-surface h-40 animate-shimmer rounded-2xl" />
      <div className="shimmer-surface h-28 animate-shimmer rounded-2xl" />
      <div className="shimmer-surface h-32 animate-shimmer rounded-2xl" />
    </div>
  );
}
