/** Скелетон карточки — используется при загрузке и «Показать ещё». */
export function SkeletonCard() {
  return (
    <div className="flex flex-col" aria-hidden="true">
      <div className="aspect-[2/3] overflow-hidden rounded-xl border border-base-700 bg-base-850">
        <div className="shimmer-surface h-full w-full animate-shimmer" />
      </div>
      <div className="mt-3 px-0.5">
        <div className="shimmer-surface h-4 w-3/4 animate-shimmer rounded-md" />
        <div className="shimmer-surface mt-2 h-3 w-1/2 animate-shimmer rounded-md" />
        <div className="mt-3 flex gap-2">
          <div className="shimmer-surface h-5 w-14 animate-shimmer rounded-md" />
          <div className="shimmer-surface h-5 w-14 animate-shimmer rounded-md" />
        </div>
      </div>
    </div>
  );
}

/** Целая сетка скелетонов. */
export function MovieGridSkeleton({ count = 10 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
      {Array.from({ length: count }, (_, index) => (
        <SkeletonCard key={index} />
      ))}
    </div>
  );
}
