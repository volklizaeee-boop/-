import { cn } from '@/lib/cn';

interface PosterPlaceholderProps {
  label?: string;
  className?: string;
}

/** Заглушка постера, если у фильма его нет. */
export function PosterPlaceholder({
  label = 'Постер отсутствует',
  className,
}: PosterPlaceholderProps) {
  return (
    <div
      className={cn(
        'flex h-full w-full flex-col items-center justify-center gap-3 bg-base-850 px-4 py-6 text-center',
        className,
      )}
    >
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-9 w-9 text-zinc-600"
        aria-hidden="true"
      >
        <rect x="2.5" y="5" width="19" height="14" rx="2.5" />
        <path d="M2.5 9.5h19M7 5v14M17 5v14" />
        <circle cx="12" cy="14.5" r="1.6" />
      </svg>
      <p className="text-xs text-zinc-500">{label}</p>
    </div>
  );
}
