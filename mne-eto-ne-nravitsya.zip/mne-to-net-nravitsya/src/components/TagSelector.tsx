import { cn } from '@/lib/cn';
import type { ResolvedTag } from '@/lib/types';
import { CheckableChip } from './CheckableChip';

interface TagSelectorProps {
  tags: ResolvedTag[];
  selected: ReadonlySet<number>;
  onToggle: (tagId: number) => void;
}

/** Жёсткий фильтр по тропам/клише (ключевые слова TMDB). */
export function TagSelector({ tags, selected, onToggle }: TagSelectorProps) {
  if (tags.length === 0) {
    return (
      <p className="text-sm text-zinc-500">
        Метки пока не загрузились. Попробуйте перезагрузить страницу.
      </p>
    );
  }

  const unresolved = tags.filter((tag) => !tag.resolved);

  return (
    <div>
      <p className="mb-3 text-xs text-zinc-500">
        Жёсткий фильтр: фильмы с отмеченными тропами исчезнут из выдачи.
      </p>

      <ul className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
        {tags.map((tag) => {
          const id = tag.id;
          if (id === null) {
            return (
              <li
                key={`${tag.keyword}-${tag.label}`}
                title={`Ключевое слово «${tag.keyword}» не найдено в TMDB`}
              >
                <CheckableChip
                  label={tag.label}
                  checked={false}
                  disabled
                  tone="warn"
                  onChange={() => undefined}
                />
              </li>
            );
          }

          return (
            <li key={id}>
              <CheckableChip
                id={`tag-${id}`}
                label={tag.label}
                checked={selected.has(id)}
                onChange={(checked) => onToggle(id)}
              />
            </li>
          );
        })}
      </ul>

      {unresolved.length > 0 && (
        <div
          role="status"
          className={cn('mt-4 rounded-xl border border-accent/30 bg-accent/5 p-4 text-sm')}
        >
          <p className="mb-1 font-semibold text-accent-200">
            Для {unresolved.length} пункта{unresolved.length === 1 ? '' : 'ев'} не нашлось ключевое слово в TMDB
          </p>
          <ul className="list-inside list-disc pl-5 text-zinc-400">
            {unresolved.map((tag) => (
              <li key={tag.keyword}>{tag.label} — «{tag.keyword}»</li>
            ))}
          </ul>
          <p className="mt-2 text-zinc-500">
            Эти пункты пропущены — запрос к TMDB выполнится без них.
          </p>
        </div>
      )}
    </div>
  );
}
