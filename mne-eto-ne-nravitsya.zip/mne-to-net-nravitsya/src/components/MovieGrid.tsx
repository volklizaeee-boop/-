'use client';

import { useState } from 'react';

import { cn } from '@/lib/cn';
import type { Movie } from '@/lib/types';
import { MovieCard } from './MovieCard';
import { MovieModal } from './MovieModal';

interface MovieGridProps {
  movies: Movie[];
  genresById: ReadonlyMap<number, string>;
  hasMore: boolean;
  isAppending: boolean;
  onLoadMore: () => void;
}

/** Адаптивная сетка карточек + модальное окно. */
export function MovieGrid({
  movies,
  genresById,
  hasMore,
  isAppending,
  onLoadMore,
}: MovieGridProps) {
  const [activeMovie, setActiveMovie] = useState<Movie | null>(null);

  return (
    <div>
      <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
        {movies.map((movie) => (
          <li key={movie.id} className="animate-fadeIn">
            <MovieCard movie={movie} genresById={genresById} onOpen={setActiveMovie} />
          </li>
        ))}
      </ul>

      <div className="mt-10 flex flex-col items-center gap-3">
        {hasMore ? (
          <button
            type="button"
            onClick={onLoadMore}
            disabled={isAppending}
            className={cn(
              'inline-flex w-full max-w-md items-center justify-center gap-2 rounded-xl border border-base-600 bg-base-900/80 px-5 py-3 text-sm font-semibold text-zinc-200 transition-colors hover:border-accent hover:text-accent disabled:cursor-not-allowed disabled:opacity-70 sm:w-auto',
            )}
          >
            {isAppending ? (
              <>
                <span className="h-4 w-4 animate-pulseSoft rounded-full border-2 border-accent border-t-transparent" />
                Загрузка…
              </>
            ) : (
              'Показать ещё'
            )}
          </button>
        ) : (
          <p className="text-sm text-zinc-500">
            Достигнут конец списка TMDB для этих фильтров.
          </p>
        )}
      </div>

      <MovieModal
        movie={activeMovie}
        genresById={genresById}
        onClose={() => setActiveMovie(null)}
      />
    </div>
  );
}
