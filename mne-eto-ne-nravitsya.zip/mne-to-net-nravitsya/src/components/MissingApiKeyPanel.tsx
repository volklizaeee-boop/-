'use client';

import { useState } from 'react';

import { cn } from '@/lib/cn';

interface MissingApiKeyPanelProps {
  title?: string;
  instructions?: readonly string[];
  className?: string;
}

const ENV_SNIPPET = 'TMDB_API_KEY="ваш_ключ_v3_here"';

/** Панель «ключ не задан»: показывает, где его взять и как подключить. */
export function MissingApiKeyPanel({
  title = 'Ключ TMDB_API_KEY не задан',
  instructions,
  className,
}: MissingApiKeyPanelProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(ENV_SNIPPET);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div
      role="alert"
      className={cn(
        'rounded-2xl border border-accent/30 bg-accent/[0.06] p-6 text-sm shadow-poster',
        className,
      )}
    >
      <div className="flex items-start gap-3">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mt-0.5 h-5 w-5 shrink-0 text-accent" aria-hidden="true">
          <circle cx="12" cy="12" r="10" />
          <path d="M12 8v4M12 16h.01" />
        </svg>
        <div className="min-w-0">
          <h2 className="m-0 text-base font-semibold text-accent-200 sm:text-lg">{title}</h2>
          <p className="mt-2 leading-relaxed text-zinc-300">
            Приложение работает без ключа, но тогда оно не может говорить с TMDB. Ключ остаётся
            только на сервере — он никогда не попадает в браузер.
          </p>

          {instructions && instructions.length > 0 && (
            <ol className="mt-4 list-inside list-decimal space-y-1.5 pl-4 text-zinc-400">
              {instructions.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
          )}

          <div className="mt-5">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-zinc-500">
              Файл .env.local
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <pre className="flex-1 overflow-x-auto rounded-xl border border-base-700 bg-base-950 px-4 py-3 font-mono text-xs text-accent-200">
                {ENV_SNIPPET}
              </pre>
              <button
                type="button"
                onClick={handleCopy}
                className="rounded-xl border border-base-600 bg-base-850 px-3 py-2.5 text-xs font-medium text-zinc-200 transition-colors hover:border-accent hover:text-accent"
              >
                {copied ? 'Скопировано' : 'Копировать'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
