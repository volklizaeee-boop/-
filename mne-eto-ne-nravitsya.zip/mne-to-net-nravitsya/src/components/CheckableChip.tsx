import { cn } from '@/lib/cn';

interface CheckableChipProps {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  disabled?: boolean;
  /** warn — пункт, для которого ключевое слово не нашлось в TMDB. */
  tone?: 'default' | 'warn';
  id?: string;
}

/**
 * Чекбокс-чип. Настоящий <input type="checkbox"> — поэтому это работает с
 * клавиатурой (Tab/Space), скринридером и формой.
 */
export function CheckableChip({
  label,
  checked,
  onChange,
  disabled = false,
  tone = 'default',
  id,
}: CheckableChipProps) {
  const inputId = id;

  return (
    <label
      htmlFor={inputId}
      className={cn(
        'group inline-flex max-w-full items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors duration-150 focus-within:ring-2 focus-within:ring-accent/70',
        'focus-visible:outline-none',
        disabled
          ? 'cursor-not-allowed border-dashed border-base-600 bg-base-900/60 text-zinc-600'
          : 'cursor-pointer select-none border-base-700 bg-base-900/70 text-zinc-300 hover:border-accent/50 hover:text-white',
        checked && !disabled
          ? 'border-accent bg-accent/15 text-accent shadow-[0_0_0_1px_rgba(245,165,36,0.35)]'
          : '',
        tone === 'warn' && !checked ? 'border-dashed' : '',
      )}
    >
      <input
        id={inputId}
        type="checkbox"
        checked={checked}
        disabled={disabled}
        onChange={(event) => onChange(event.target.checked)}
        className="sr-only"
      />
      {checked && !disabled && (
        <span aria-hidden="true" className="text-xs font-bold leading-none">
          ✕
        </span>
      )}
      <span className="truncate">{label}</span>
    </label>
  );
}
