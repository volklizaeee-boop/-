import { cn } from '@/lib/cn';
import { formatRating, formatVoteCount, formatYear } from '@/lib/format';
import { getPosterUrl } from '@/lib/images';
import type { Movie } from '@/lib/types';
import { PosterPlaceholder } from './PosterPlaceholder';

interface MovieCardProps {
  movie: Movie;
  /** id жанра → название для карточки. */
  genresById: ReadonlyMap<number, string>;
  onOpen: (movie: Movie) => void;
}

/** Карточка фильма. Клик/Enter/Space открывает модальное окно. */
export function MovieCard({ movie, genresById, onOpen }: MovieCardProps) {
  const poster = getPosterUrl(movie.posterPath, 'w500');
  const year = formatYear(movie.releaseDate);
  const rating = formatRating(movie.voteAverage);
  const voteCount = formatVoteCount(movie.voteCount);
  const genreNames = movie.genreIds
    .map((id) => genresById.get(id))
    .filter((name): name is string => Boolean(name));

  return (
    <button
      type="button"
      onClick={() => onOpen(movie)}
      className="group flex w-full flex-col text-left focus-visible:outline-none"
      aria-label={`${movie.title}${year ? `, ${year}` : ''} — подробнее`}
    >
      <div className="relative aspect-[2/3] overflow-hidden rounded-xl border border-base-700 bg-base-850 shadow-poster transition-transform duration-200 group-hover:-translate-y-1 group-hover:border-accent/50">
        {poster ? (
          <img
            src={poster}
            alt={`Постер фильма «${movie.title}»`}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.04]"
          />
        ) : (
          <PosterPlaceholder label="Постер отсутствует" className="h-full w-full" />
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />

        <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 p-3">
          <div className="min-w-0">
            {year && (
              <p className="text-xs font-medium text-zinc-200/90">{year}</p>
            )}
          </div>
          {rating && (
            <span className="inline-flex items-center gap-1 rounded-lg bg-black/70 px-2 py-1 text-xs font-bold text-accent backdrop-blur">
              <svg viewBox="0 0 24 24" fill="currentColor" className="h-3 w-3" aria-hidden="true">
                <path d="m12 17.27 5.18 3.12-1.37-5.9 4.58-3.97-6.02-.51L12 4.5 9.61 10l-6.02.51 4.58 3.97-1.37 5.9z" />
              </svg>
              {rating}
            </span>
          )}
        </div>
      </div>

      <div className="mt-3 px-0.5">
        <h3 className={cn('truncate text-sm font-semibold text-zinc-50')}>{movie.title}</h3>
        <p className="mt-0.5 text-xs text-zinc-500">
          {voteCount ? `${voteCount} оценок` : 'Нет оценок'}
        </p>
        {genreNames.length > 0 && (
          <ul className="mt-2 flex flex-wrap gap-1">
            {genreNames.slice(0, 3).map((name) => (
              <li
                key={name}
                className="rounded-md border border-base-700 bg-base-900/80 px-2 py-0.5 text-[11px] text-zinc-400"
              >
                {name}
              </li>
            ))}
          </ul>
        )}
      </div>
    </button>
  );
}
