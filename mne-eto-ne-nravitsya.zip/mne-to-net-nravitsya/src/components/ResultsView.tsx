'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

import { ENDING_FILTER_NOTE } from '@/lib/filters';
import { ApiClientError, fetchGenres, fetchMoviesPage, fetchTags } from '@/lib/movie-api';
import type { EndingPreference, Movie, ResolvedTag, TmdbGenre } from '@/lib/types';
import { FilterSummary } from './FilterSummary';
import { MovieGrid } from './MovieGrid';
import { MovieGridSkeleton } from './SkeletonCard';
import { MissingApiKeyPanel } from './MissingApiKeyPanel';

interface MoviePageState {
  movies: Movie[];
  unresolvedKeywords: string[];
  page: number;
  totalPages: number;
  totalResults: number;
}

interface ErrorState {
  code: string;
  message: string;
  instructions: string[] | null;
}

/** «1,2,3» → [1, 2, 3]. */
function parseIdList(raw: string | null): number[] {
  if (!raw) return [];
  return raw
    .split(',')
    .map((chunk) => Number.parseInt(chunk.trim(), 10))
    .filter((value) => Number.isInteger(value) && value > 0);
}

function parseEnding(raw: string | null): EndingPreference {
  return raw === 'good' || raw === 'sad' ? raw : 'any';
}

function parsePage(raw: string | null): number {
  const parsed = Number.parseInt(raw ?? '', 10);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : 1;
}

export function ResultsView() {
  const router = useRouter();
  const searchParams = useSearchParams();

  // Простые стринги-зависимости, чтобы мемоизация не срывалась на каждом рендере.
  const genresParam = searchParams.get('exclude_genres') ?? '';
  const tagsParam = searchParams.get('exclude_keywords') ?? '';
  const endingParam = searchParams.get('ending') ?? '';
  const pageParam = searchParams.get('page') ?? '';

  const excludeGenres = useMemo(() => parseIdList(genresParam), [genresParam]);
  const excludeKeywords = useMemo(() => parseIdList(tagsParam), [tagsParam]);
  const ending = useMemo(() => parseEnding(endingParam), [endingParam]);
  const page = useMemo(() => parsePage(pageParam), [pageParam]);

  /** Что вообще поменялось — на это и перезагружаем список с первой страницы. */
  const requestKey = useMemo(
    () => `${excludeGenres.join(',')}|${excludeKeywords.join(',')}|${ending}`,
    [excludeGenres, excludeKeywords, ending],
  );

  const [moviePage, setMoviePage] = useState<MoviePageState | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAppending, setIsAppending] = useState(false);
  const [error, setError] = useState<ErrorState | null>(null);

  const [genres, setGenres] = useState<TmdbGenre[]>([]);
  const [tags, setTags] = useState<ResolvedTag[]>([]);

  const moviePageRef = useRef<MoviePageState | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const genresById = useMemo(
    () => new Map(genres.map((genre) => [genre.id, genre.name])),
    [genres],
  );
  const tagsById = useMemo(
    () =>
      new Map(
        tags
          .filter((tag): tag is ResolvedTag & { id: number } => tag.id !== null)
          .map((tag) => [tag.id, tag.label]),
      ),
    [tags],
  );

  /* ---------------- метаданные для подписей фильтров ---------------- */

  useEffect(() => {
    const controller = new AbortController();

    Promise.all([fetchGenres(controller.signal), fetchTags(controller.signal)])
      .then(([genreList, tagList]) => {
        setGenres(genreList);
        setTags(tagList.tags);
      })
      .catch(() => {
        /* метаданные опциональны: FilterSummary просто покажет количество без подписей */
      });

    return () => controller.abort();
  }, []);

  /* ---------------- загрузка фильмов ---------------- */

  const loadPage = useCallback(
    async (targetPage: number, options: { replace: boolean }) => {
      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;

      setError(null);
      setIsLoading(true);
      setIsAppending(!options.replace && moviePageRef.current !== null);

      try {
        const result = await fetchMoviesPage(
          { excludeGenres, excludeKeywords, ending, page: targetPage },
          controller.signal,
        );

        if (controller.signal.aborted) return;

        const previousMovies = options.replace ? [] : (moviePageRef.current?.movies ?? []);
        const next: MoviePageState = {
          movies: [...previousMovies, ...result.movies],
          unresolvedKeywords: result.unresolvedKeywords ?? [],
          page: result.page,
          totalPages: result.totalPages,
          totalResults: result.totalResults,
        };

        moviePageRef.current = next;
        setMoviePage(next);
      } catch (cause) {
        if (controller.signal.aborted) return;

        if (cause instanceof ApiClientError) {
          setError({
            code: cause.code,
            message: cause.message,
            instructions: cause.instructions,
          });
        } else {
          setError({
            code: 'NETWORK_ERROR',
            message: 'Не удалось загрузить фильмы — проверьте подключение и попробуйте ещё раз.',
            instructions: null,
          });
        }
      } finally {
        if (!controller.signal.aborted) {
          setIsLoading(false);
          setIsAppending(false);
        }
      }
    },
    [excludeGenres, excludeKeywords, ending],
  );

  // Перезагружаем текущую страницу при смене фильтров, URL или команды «показать ещё».
  useEffect(() => {
    const previous = moviePageRef.current;
    const shouldAppend = page > 1 && previous !== null && previous.page === page - 1;
    void loadPage(page, { replace: !shouldAppend });
  }, [requestKey, page, loadPage]);

  /* ---------------- рендер ---------------- */

  const hasMore = moviePage !== null && moviePage.page < moviePage.totalPages;
  const isInitialLoading = isLoading && moviePage === null;
  const isEmpty = moviePage !== null && moviePage.movies.length === 0;

  return (
    <main className="mx-auto w-full max-w-7xl px-4 pb-24 pt-6 sm:px-6">
      <header className="mb-6 space-y-4">
        <div className="flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => router.push('/')}
            className="inline-flex items-center gap-1.5 rounded-lg border border-base-700 bg-base-900/70 px-3 py-2 text-sm font-medium text-zinc-300 transition-colors hover:border-accent hover:text-accent"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4" aria-hidden="true">
              <path d="m15 18-6-6 6-6" />
            </svg>
            Назад
          </button>
          <p className="text-sm text-zinc-500">Результаты подборки</p>
        </div>

        <FilterSummary
          variant="compact"
          excludedGenres={excludeGenres}
          excludedTags={excludeKeywords}
          ending={ending}
          genresById={genresById}
          tagsById={tagsById}
          onEditFilters={() => router.push(`/?${new URLSearchParams({ exclude_genres: genresParam, exclude_keywords: tagsParam, ending }).toString()}`)}
        />

        {ending !== 'any' && (
          <p className="m-0 text-xs leading-relaxed text-zinc-500">{ENDING_FILTER_NOTE}</p>
        )}
      </header>

      {moviePage && moviePage.unresolvedKeywords.length > 0 && (
        <p role="status" className="mb-4 rounded-xl border border-base-600 p-3 text-sm text-zinc-300">
          Некоторые слова финала не найдены в TMDB и пропущены: {moviePage.unresolvedKeywords.join(', ')}.
        </p>
      )}
      {error?.instructions ? (
        <MissingApiKeyPanel instructions={error.instructions} />
      ) : error ? (
        <div className="rounded-2xl border border-danger/40 bg-danger/[0.07] p-8 text-center">
          <p className="m-0 font-semibold text-danger">{error.message}</p>
          <div className="mt-5 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              onClick={() => void loadPage(page, { replace: !(moviePageRef.current && moviePageRef.current.page === page - 1) })}
              className="rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-base-950 transition-colors hover:bg-accent-400"
            >
              Повторить
            </button>
            <button
              type="button"
              onClick={() => router.push('/')}
              className="rounded-xl border border-base-600 px-5 py-2.5 text-sm font-semibold text-zinc-200 transition-colors hover:border-accent hover:text-accent"
            >
              Назад к фильтрам
            </button>
          </div>
        </div>
      ) : isInitialLoading ? (
        <div className="space-y-6">
          <MovieGridSkeleton count={10} />
        </div>
      ) : isEmpty ? (
        <div className="rounded-2xl border border-base-700 bg-base-900/60 p-8 text-center">
          <p className="m-0 font-semibold text-zinc-50">Слишком много исключений</p>
          <p className="mt-2 text-sm leading-relaxed text-zinc-400">
            Ничего не нашлось под текущие фильтры — попробуйте убрать часть жанров или меток.
          </p>
          <button
            type="button"
            onClick={() => router.push('/')}
            className="mt-5 rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-base-950 transition-colors hover:bg-accent-400"
          >
            Изменить фильтры
          </button>
        </div>
      ) : moviePage ? (
        <>
          <MovieGrid
            movies={moviePage.movies}
            genresById={genresById}
            hasMore={hasMore}
            isAppending={isAppending}
            onLoadMore={() => {
              const next = new URLSearchParams(searchParams.toString());
              next.set('page', String(moviePage.page + 1));
              router.push(`/results?${next.toString()}`);
            }}
          />
          <p className="mt-6 text-center text-xs text-zinc-600">
            Показано {moviePage.movies.length} из {moviePage.totalResults.toLocaleString('ru-RU')} фильмов
            (страница {moviePage.page} из {moviePage.totalPages})
          </p>
        </>
      ) : null}
    </main>
  );
}
