'use client';

import { useEffect, useRef } from 'react';

import { cn } from '@/lib/cn';
import { formatRating, formatVoteCount, formatYear } from '@/lib/format';
import { getPosterUrl } from '@/lib/images';
import type { Movie } from '@/lib/types';
import { PosterPlaceholder } from './PosterPlaceholder';

interface MovieModalProps {
  movie: Movie | null;
  genresById: ReadonlyMap<number, string>;
  onClose: () => void;
}

/** Модальное окно с фильмом. Закрытие по Esc и клику вне окна. */
export function MovieModal({ movie, genresById, onClose }: MovieModalProps) {
  const closeButtonRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (!movie) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    closeButtonRef.current?.focus();

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [movie, onClose]);

  if (!movie) return null;

  const poster = getPosterUrl(movie.posterPath, 'original');
  const year = formatYear(movie.releaseDate);
  const rating = formatRating(movie.voteAverage);
  const voteCount = formatVoteCount(movie.voteCount);
  const genreNames = movie.genreIds
    .map((id) => genresById.get(id))
    .filter((name): name is string => Boolean(name));

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center p-3 sm:items-center sm:p-6"
      role="presentation"
    >
      <button
        type="button"
        aria-label="Закрыть"
        onClick={onClose}
        tabIndex={-1}
        className="absolute inset-0 animate-fadeIn bg-black/75 backdrop-blur-sm"
      />

      <div
        role="dialog"
        aria-modal="true"
        aria-label={`${movie.title}${year ? `, ${year}` : ''}`}
        className={cn(
          'relative z-10 max-h-[92vh] w-full max-w-3xl animate-scaleIn overflow-y-auto rounded-t-3xl border border-base-700 bg-base-900 shadow-panel sm:rounded-3xl',
        )}
      >
        <button
          ref={closeButtonRef}
          type="button"
          onClick={onClose}
          className="absolute right-3 top-3 z-10 inline-flex h-9 w-9 items-center justify-center rounded-full border border-base-600 bg-base-900/90 text-zinc-300 transition-colors hover:border-danger hover:text-danger"
          aria-label="Закрыть окно"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" className="h-4 w-4" aria-hidden="true">
            <path d="M18 6 6 18M6 6l12 12" />
          </svg>
        </button>

        <div className="grid md:grid-cols-[minmax(0,240px)_minmax(0,1fr)]">
          <div className="relative md:sticky md:top-0 md:self-start">
            <div className="aspect-[2/3] overflow-hidden border-b border-base-700 bg-base-850 md:aspect-auto md:min-h-[26rem] md:rounded-l-3xl">
              {poster ? (
                <img
                  src={poster}
                  alt={`Постер фильма «${movie.title}»`}
                  className="h-full w-full object-cover"
                />
              ) : (
                <PosterPlaceholder label="Постер отсутствует" className="h-full w-full" />
              )}
            </div>
          </div>

          <div className="p-5 sm:p-6">
            <h2 className="text-xl font-bold leading-snug text-zinc-50 sm:text-2xl">{movie.title}</h2>

            <dl className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
              {year && (
                <div>
                  <dt className="text-xs text-zinc-500">Год</dt>
                  <dd className="text-sm font-medium text-zinc-200">{year}</dd>
                </div>
              )}
              {rating && (
                <div>
                  <dt className="text-xs text-zinc-500">Рейтинг</dt>
                  <dd className="inline-flex items-center gap-1 font-semibold text-accent">
                    <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4" aria-hidden="true">
                      <path d="m12 17.27 5.18 3.12-1.37-5.9 4.58-3.97-6.02-.51L12 4.5 9.61 10l-6.02.51 4.58 3.97-1.37 5.9z" />
                    </svg>
                    {rating}
                  </dd>
                </div>
              )}
              {voteCount && (
                <div>
                  <dt className="text-xs text-zinc-500">Оценок</dt>
                  <dd className="text-sm font-medium text-zinc-200">{voteCount}</dd>
                </div>
              )}
            </dl>

            {genreNames.length > 0 && (
              <ul className="mt-4 flex flex-wrap gap-2">
                {genreNames.map((name) => (
                  <li
                    key={name}
                    className="rounded-lg border border-base-700 bg-base-850/80 px-2.5 py-1 text-xs text-zinc-300"
                  >
                    {name}
                  </li>
                ))}
              </ul>
            )}

            <div className="mt-5">
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-zinc-500">
                Описание
              </h3>
              <p className="text-sm leading-relaxed text-zinc-300">
                {movie.overview && movie.overview.trim().length > 0 ? (
                  movie.overview
                ) : (
                  'Описание отсутствует в базе TMDB.'
                )}
              </p>
            </div>

            <p className="mt-5 text-xs text-zinc-600">
              Нажмите Esc или кликните на площадь за окном, чтобы закрыть.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
