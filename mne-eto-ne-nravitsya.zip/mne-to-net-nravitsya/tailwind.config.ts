export default {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: {
          950: '#070709',
          900: '#0d0d10',
          850: '#141418',
          800: '#1b1b21',
          750: '#23232a',
          700: '#2c2c34',
          600: '#3d3d47',
          500: '#575762',
        },
        accent: {
          DEFAULT: '#f5a524',
          200: '#fde6b3',
          300: '#fbd488',
          400: '#f7b53d',
          500: '#f5a524',
          600: '#d98a12',
          700: '#b36f0c',
        },
        danger: {
          DEFAULT: '#e5484d',
          soft: '#8f2b30',
        },
      },
      boxShadow: {
        poster: '0 20px 45px -25px rgba(0, 0, 0, 0.9)',
        panel: '0 30px 80px -30px rgba(0, 0, 0, 0.95)',
        glow: '0 0 0 1px rgba(245, 165, 36, 0.35), 0 12px 30px -12px rgba(245, 165, 36, 0.25)',
      },
      fontFamily: {
        sans: [
          'ui-sans-serif',
          'system-ui',
          '-apple-system',
          'Segoe UI',
          'Roboto',
          'Helvetica Neue',
          'Arial',
          'sans-serif',
        ],
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        scaleIn: {
          '0%': { opacity: '0', transform: 'translateY(12px) scale(0.98)' },
          '100%': { opacity: '1', transform: 'translateY(0) scale(1)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-700px 0' },
          '100%': { backgroundPosition: '700px 0' },
        },
        pulseSoft: {
          '0%, 100%': { opacity: '0.55' },
          '50%': { opacity: '1' },
        },
      },
      animation: {
        fadeIn: 'fadeIn 0.22s ease-out both',
        scaleIn: 'scaleIn 0.24s cubic-bezier(0.22, 1, 0.36, 1) both',
        shimmer: 'shimmer 1.5s ease-in-out infinite',
        pulseSoft: 'pulseSoft 1.4s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
