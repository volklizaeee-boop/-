# «Мне это не нравится» — подборщик фильмов

Вы отмечаете то, чего **не хотите видеть** (жанры, тропы/клише, финал), а сайт показывает
оставшееся из TMDB. Без базы данных: всё состояние — в URL.

## Как запустить

```bash
npm install
npm run dev
# http://localhost:3000
```

## Как получить ключ TMDB

1. Зарегистрируйтесь на [themoviedb.org](https://www.themoviedb.org/) (бесплатно) и войдите.
2. Профиль → **API** (<https://www.themoviedb.org/settings/api>) → кнопка **Create**.
3. Скопируйте ключ API v3.
4. В корне проекта создайте `.env.local`:

   ```bash
   TMDB_API_KEY="ваш_ключ_v3"
   ```

5. Перезапустите `npm run dev`.

> Ключ живёт только на сервере. Все запросы к TMDB идут через Route Handler
> (`src/app/api/movies/route.ts`), так что он никогда не попадает в браузер.
> Если ключа нет — приложение показывает пошаговую инструкцию.

## Три слоя фильтрации

| Слой | Тип | Как работает |
| --- | --- | --- |
| **Жанры** | жёсткий | `/discover/movie?without_genres=…` |
| **Метки / тропы** | жёсткий | `/discover/movie?without_keywords=…`, ID резолвятся через `/search/keyword` и кэшатся в памяти |
| **Финал** | мягкий | те же `without_keywords`, но ключевые слова `sad ending` / `tragic ending` / `happy ending`; фильмы без разметки TMDB остаются в выдаче |

TMDB возвращает ограниченный официальный список жанров; многие перечисленные поджанры и направления не являются отдельными жанрами TMDB. Их можно представить метками, но не параметром `without_genres`. Ключевое слово `bittersweet ending` также разрешается и кэшируется, но не исключается ни в одном из двух режимов согласно заданной логике.

## Проект

```
src/
  app/
    layout.tsx                  # корневой layout, метаданные
    globals.css                 # тема, Tailwind
    page.tsx                    # главная: три аккордеона фильтров + счётчик
    results/page.tsx            # /results — Suspense для useSearchParams
    api/movies/route.ts         # ← запрос фильмов, GET /api/movies
  components/
    GenreSelector.tsx           # сетка чипов жанров
    TagSelector.tsx             # сетка чипов тропов + «не нашлось ключевое слово»
    EndingSelector.tsx          # радиогруппа «Не важно / Хороший / Грустный»
    MovieCard.tsx               # постер, название, год, рейтинг, жанры
    MovieGrid.tsx               # адаптивная сетка + модальное окно
    MovieModal.tsx              # Esc, клик вне окна, блокировка скролла
    SkeletonCard.tsx            # скелетон карточки / сетка
    FilterSummary.tsx           # «Исключено: X жанров, Y меток»
    CheckableChip.tsx           # чекбокс-чип
    AccordionSection.tsx        # аккордеон (aria-expanded)
    PosterPlaceholder.tsx       # заглушка без постера
    MissingApiKeyPanel.tsx      # инструкция, где взять ключ
    FilterSkeleton.tsx          # скелетон фильтров
    ResultsView.tsx             # логика страницы /results
  lib/
    types.ts                    # все публичные типы (без any)
    filters.ts                  # TAGS (RU label + EN keyword), ENDING_FILTER, подписи
    tmdb.ts                     # серверный клиент TMDB + in-memory кэш ключевых слов
    images.ts                   # публичные ссылки на постеры
    movie-api.ts                # клиентские fetch к Route Handler
    format.ts                   # plural, даты, рейтинги
    cn.ts                       # className joiner
```

## Поделиться ссылкой

```
/results?exclude_genres=18,35&exclude_keywords=53,10762&ending=good&page=2
```

Параметры: `exclude_genres` (ID через запятую), `exclude_keywords` (ID через запятую),
`ending` (`any` | `good` | `sad`), `page`.

## Команды

```bash
npm run dev        # dev server
npm run build      # production build
npm run typecheck  # tsc --noEmit
```
